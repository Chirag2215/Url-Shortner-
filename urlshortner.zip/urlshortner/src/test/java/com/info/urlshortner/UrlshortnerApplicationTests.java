package com.info.urlshortner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UrlshortnerApplicationTests {

	@Test
	void contextLoads() {
	}

}
